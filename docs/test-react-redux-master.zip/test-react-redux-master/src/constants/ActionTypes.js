export const ADD_TODO = 'ADD_TODO';
export const DELETE_TODO = 'DELETE_TODO';
export const EDIT_TODO = 'EDIT_TODO';
export const MARK_TODO = 'MARK_TODO';
export const MARK_ALL = 'MARK_ALL';
export const CLEAR_MARKED = 'CLEAR_MARKED';
